---
title: "Labour — Standard Hours"
summary: General work billed in 30-minute increments (min 30 mins).
price: "R450/hr"
category: "Support"
bullets:
  - Standard business hours
  - Billed per 30 minutes (min 30)
  - Fair, transparent time tracking
faqs:
  - q: "When is this used?"
    a: "For custom/complex tasks not listed as fixed-price services."
---

Transparent hourly work for unique or complex issues outside fixed items.
