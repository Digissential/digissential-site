---
title: "Labour — After-Hours / Emergency"
summary: Weekdays after 17:30, weekends, and public holidays.
price: "R650/hr"
category: "Support"
bullets:
  - After-hours availability
  - Billed in 30-minute increments
  - Fair escalation for urgent cases
faqs:
  - q: "Can I book this in advance?"
    a: "Yes—contact us to schedule urgent work and we’ll confirm availability."
---

For time-critical issues when you need help outside normal hours.
